import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  FaArrowRight,
  FaAws,
  FaBars,
  FaBrain,
  FaCloud,
  FaDatabase,
  FaEnvelope,
  FaGithub,
  FaJava,
  FaKubernetes,
  FaLinkedin,
  FaMapMarkerAlt,
  FaReact,
  FaServer,
  FaTimes,
  FaCodeBranch,
  FaShieldAlt,
  FaChartLine,
  FaExternalLinkAlt
} from "react-icons/fa";

const experiences = [
  { company: "Goldman Sachs", role: "Senior Software Engineer", period: "April 2025 – Present", location: "New York, NY", description: "Building Java 21 and Spring Boot microservices, secure REST APIs, Kafka workflows, React dashboards and AWS EKS workloads for a large-scale credit-card portfolio migration and financial-platform modernization initiative." },
  { company: "DaVita Health Care", role: "Senior Software Engineer", period: "June 2023 – March 2025", location: "Denver, CO", description: "Developed secure healthcare microservices and responsive applications using Java 17, Spring Boot, Angular, React, Kafka, Oracle, MongoDB, Cassandra and Azure AKS." },
  { company: "Morgan Stanley", role: "Senior Software Engineer", period: "September 2021 – May 2023", location: "New York, NY", description: "Built equity trading, portfolio management and trade-lifecycle capabilities with Java 11, Spring Boot, React, Kafka, Oracle, AWS and Kubernetes." },
  { company: "Big Lots", role: "Software Engineer", period: "January 2020 – August 2021", location: "Columbus, OH", description: "Developed retail applications for inventory, warehouse operations, product catalog, purchasing and order fulfillment using Java 8, Spring, React, Oracle, IBM MQ and AWS." },
  { company: "App Labs", role: "Software Engineer", period: "July 2016 – November 2019", location: "Hyderabad, India", description: "Built enterprise Java/J2EE applications using Spring MVC, JDBC, Hibernate, REST/SOAP services, Oracle, JSP, JavaScript and Jenkins across Agile and Waterfall delivery." }
];

const skills = [
  { category: "Backend Engineering", description: "Enterprise services, APIs and distributed application design.", items: ["Java 8/11/17/21", "Spring Boot", "Spring MVC", "Spring Security", "Spring Data JPA", "Hibernate", "REST APIs", "Microservices", "JAX-RS", "OAuth 2.0", "JWT"] },
  { category: "Frontend Development", description: "Responsive interfaces connected to secure enterprise workflows.", items: ["ReactJS", "Angular", "TypeScript", "JavaScript ES6+", "Redux Toolkit", "HTML5", "CSS3", "Bootstrap", "React Router"] },
  { category: "Cloud & DevOps", description: "Containerized delivery, infrastructure and production operations.", items: ["AWS", "Azure", "GCP", "Docker", "Kubernetes", "AWS EKS", "Azure AKS", "Terraform", "Ansible", "Jenkins", "GitHub Actions", "Maven"] },
  { category: "Data & Messaging", description: "High-volume data processing and asynchronous integration.", items: ["Oracle 11g/19c", "SQL", "PL/SQL", "MongoDB", "Cassandra", "Apache Kafka", "IBM MQ", "JMS", "Spring Batch"] },
  { category: "AI Engineering", description: "Practical AI capabilities for enterprise engineering workflows.", items: ["LLM APIs", "Spring AI", "LangChain4j", "RAG", "Vector DBs", "AI Agents", "MCP", "Prompt Engineering"] },
  { category: "Quality & Observability", description: "Testing, diagnostics, monitoring and controlled releases.", items: ["JUnit 5", "Mockito", "Spring Boot Test", "Selenium", "Postman", "OpenAPI/Swagger", "Splunk", "Grafana", "Prometheus", "Log4j2", "SonarQube", "Nexus"] }
];

const caseStudies = [
  { id: "financial-migration", eyebrow: "GOLDMAN SACHS · FINANCIAL SERVICES", title: "Financial Portfolio Migration", summary: "Migration engineering for customer, account, payment and servicing data with traceability, reconciliation and controlled recovery.", technologies: ["Java 21", "Spring Boot", "Kafka", "React", "Oracle 19c", "MongoDB", "AWS EKS"], icon: FaChartLine, details: ["Designed migration microservices and secure REST APIs for initiation, validation, status tracking, reconciliation and failed-record reprocessing.", "Built source-to-target mappings, transformation rules, validation components and record-level auditability.", "Implemented Kafka-based asynchronous processing with retries, ordered execution and controlled failure recovery.", "Created React/Redux operational dashboards for batch progress, validation failures, reconciliation results and authorized reprocessing.", "Integrated AI agents to analyze failed records, support retry/reprocessing actions and surface reconciliation exceptions for operational follow-up."] },
  { id: "trading-platform", eyebrow: "MORGAN STANLEY · CAPITAL MARKETS", title: "Trading & Portfolio Platform", summary: "Distributed services supporting trade execution, settlement, position management and portfolio reconciliation.", technologies: ["Java 11", "Spring Boot", "React", "Kafka", "Oracle 19c", "AWS", "Kubernetes"], icon: FaChartLine, details: ["Built reusable business modules for trade execution, settlement, position management and portfolio reconciliation.", "Developed secure REST APIs and React dashboards for real-time position, transaction and market-activity visibility.", "Used Kafka for trade events, market notifications, settlement updates and portfolio synchronization.", "Containerized services with Docker and Kubernetes and deployed cloud infrastructure on AWS."] },
  { id: "healthcare", eyebrow: "DAVITA HEALTH CARE · HEALTHCARE", title: "Healthcare Platform Modernization", summary: "Secure healthcare workflows spanning patient data, scheduling, referrals, batch synchronization and event-driven notifications.", technologies: ["Java 17", "Spring Boot", "Angular", "Kafka", "Oracle 19c", "MongoDB", "Azure AKS"], icon: FaShieldAlt, details: ["Built microservices for patient demographics, laboratory orders, insurance information, pharmacy requests and clinical documents.", "Implemented Spring Batch jobs for enrollment, historical-record migration, claims reconciliation and nightly synchronization.", "Used Kafka for appointment reminders, laboratory notifications, insurance status updates and physician alerts.", "Deployed Java services to Azure AKS with Key Vault, Application Insights, Azure Monitor and Log Analytics."] }
];

const architectureSteps = [
  { label: "Experience", value: "React / Angular", icon: FaReact },
  { label: "API Layer", value: "Spring Boot REST", icon: FaServer },
  { label: "Services", value: "Microservices", icon: FaCodeBranch },
  { label: "Events", value: "Kafka / JMS", icon: FaCloud },
  { label: "Data", value: "Oracle / MongoDB / Cassandra", icon: FaDatabase },
  { label: "Runtime", value: "AWS / Azure / Kubernetes", icon: FaKubernetes }
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeCase, setActiveCase] = useState(null);

  useEffect(() => {
    const update = () => {
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(height > 0 ? (window.scrollY / height) * 100 : 0);
    };
    window.addEventListener("scroll", update);
    update();
    return () => window.removeEventListener("scroll", update);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="app">
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />
      <div className="background-effects" aria-hidden="true"><div className="background-orb orb-one" /><div className="background-orb orb-two" /><div className="background-grid" /></div>

      <nav className="navbar">
        <div className="navbar-container">
          <a href="#home" className="logo" onClick={closeMenu}>TV</a>
          <button className="menu-button" type="button" aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <FaTimes /> : <FaBars />}</button>
          <ul className={menuOpen ? "nav-links nav-links-open" : "nav-links"}>
            {[["#about", "About"], ["#experience", "Experience"], ["#skills", "Skills"], ["#work", "Work"], ["#architecture", "Architecture"], ["#contact", "Contact"]].map(([href, label]) => <li key={href}><a href={href} onClick={closeMenu}>{label}</a></li>)}
          </ul>
        </div>
      </nav>

      <main>
        <section className="hero" id="home">
          <div className="hero-container">
            <motion.div className="hero-content" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}>
              <div className="availability-badge"><span className="availability-dot" /> Open to Senior Java Full Stack opportunities</div>
              <p className="hero-eyebrow">JAVA · FULL STACK · CLOUD · AI</p>
              <h1>Engineering reliable software for <span>complex enterprise systems.</span></h1>
              <p className="hero-description">I&apos;m Teja Vikas Donepudi, a Senior Java Full Stack Developer with 10+ years of experience across financial services, healthcare and retail — from enterprise Java foundations to cloud-native modernization and AI-enabled workflows.</p>
              <div className="hero-actions"><a href="#work" className="primary-button">Explore case studies <FaArrowRight /></a><a href={`${import.meta.env.BASE_URL}resume.pdf`} className="secondary-button" target="_blank" rel="noreferrer">View résumé</a></div>
              <div className="hero-socials"><a href="https://github.com/vikas534ai" target="_blank" rel="noreferrer" aria-label="GitHub"><FaGithub /></a><a href="https://www.linkedin.com/in/tejavikasd534/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><FaLinkedin /></a><a href="mailto:vikas534ai@gmail.com" aria-label="Email"><FaEnvelope /></a></div>
            </motion.div>

            <motion.aside className="hero-profile-card" initial={{ opacity: 0, x: 35 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: .75, delay: .15 }}>
              <div className="profile-photo-placeholder" aria-label="Professional profile photo placeholder"><span>TV</span><small>Add profile photo</small></div>
              <div className="profile-card-header"><div><h2>Teja Vikas Donepudi</h2><p>Senior Software Engineer</p></div></div>
              <div className="profile-location"><FaMapMarkerAlt /> Harrison, New Jersey</div>
              <div className="profile-divider" />
              <p className="profile-summary">Java and Spring Boot backend engineering, React/Angular interfaces, event-driven systems, cloud infrastructure and production-grade operational tooling.</p>
              <div className="profile-technologies">
                <div className="technology-row"><span className="technology-icon"><FaJava /></span><div><strong>Backend</strong><p>Java 8/11/17/21 · Spring Boot</p></div></div>
                <div className="technology-row"><span className="technology-icon"><FaReact /></span><div><strong>Full Stack</strong><p>React · Angular · TypeScript</p></div></div>
                <div className="technology-row"><span className="technology-icon"><FaAws /></span><div><strong>Cloud</strong><p>AWS · Azure · Kubernetes</p></div></div>
                <div className="technology-row"><span className="technology-icon"><FaBrain /></span><div><strong>AI Engineering</strong><p>Agents · RAG · LLM APIs</p></div></div>
              </div>
              <div className="profile-card-footer"><span className="status-indicator" /> Hands-on senior engineering focus</div>
            </motion.aside>
          </div>
        </section>

        <section className="credibility-strip" aria-label="Career highlights"><div className="credibility-container"><div className="credibility-item"><strong>10+</strong><span>Years experience</span></div><div className="credibility-item"><strong>5</strong><span>Organizations</span></div><div className="credibility-item"><strong>3</strong><span>Industry domains</span></div><div className="credibility-item"><strong>Java + AI</strong><span>Modern engineering focus</span></div></div></section>

        <motion.section id="about" className="section about-section" initial={{ opacity: 0, y: 45 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .7 }}>
          <div className="section-heading"><p>About Me</p><h2>From Java foundations to enterprise modernization</h2></div>
          <div className="about-grid"><div className="about-copy"><p>My career started with Java and J2EE enterprise development at App Labs and expanded through retail platforms, capital-markets systems, healthcare applications and financial-platform modernization.</p><p>Today I work across the full development lifecycle: designing Java/Spring Boot microservices and secure APIs, building React and Angular interfaces, integrating data and messaging systems, deploying cloud-native workloads and supporting production operations.</p><p>I also apply AI agents to practical engineering workflows such as retry mechanisms, reconciliation checks and failed-record reprocessing — using AI where it can improve operational reliability without replacing controlled engineering processes.</p></div><div className="about-stats"><div className="stat-card"><span>10+</span><p>Years of software engineering</p></div><div className="stat-card"><span>Finance</span><p>Trading and financial-platform experience</p></div><div className="stat-card"><span>Cloud</span><p>AWS, Azure and Kubernetes delivery</p></div><div className="stat-card"><span>AI</span><p>Agent-assisted enterprise workflows</p></div></div></div>
        </motion.section>

        <section id="experience" className="section experience-section"><div className="section-heading"><p>Career Journey</p><h2>Professional Experience</h2></div><div className="timeline">{experiences.map((experience, index) => <motion.article className="timeline-item" key={experience.company} initial={{ opacity: 0, x: index % 2 === 0 ? -35 : 35 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .15 }} transition={{ duration: .6 }}><div className="timeline-dot" /><div className="experience-card"><div className="experience-header"><div><h3>{experience.company}</h3><h4>{experience.role}</h4></div><div className="experience-meta"><span>{experience.period}</span><span>{experience.location}</span></div></div><p>{experience.description}</p></div></motion.article>)}</div></section>

        <section id="skills" className="section skills-section"><div className="section-heading"><p>Technical Expertise</p><h2>A stack built for enterprise delivery</h2></div><div className="skills-grid">{skills.map((group, index) => <motion.article className="skill-card" key={group.category} initial={{ opacity: 0, y: 35 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .6, delay: index * .06 }}><p className="skill-number">{String(index + 1).padStart(2, "0")}</p><h3>{group.category}</h3><p className="skill-description">{group.description}</p><div className="skill-tags">{group.items.map(skill => <span key={skill}>{skill}</span>)}</div></motion.article>)}</div></section>

        <section id="architecture" className="section architecture-section"><div className="section-heading"><p>Engineering Approach</p><h2>How I think about enterprise systems</h2></div><p className="architecture-intro">A typical solution connects user experience, secure APIs, distributed services, event-driven integration, persistent data and cloud operations. The implementation changes by domain, but the engineering principles stay consistent.</p><div className="architecture-flow">{architectureSteps.map((step, index) => <motion.div className="architecture-node" key={step.label} initial={{ opacity: 0, scale: .92 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: .45, delay: index * .08 }}><span className="architecture-icon"><step.icon /></span><small>{step.label}</small><strong>{step.value}</strong>{index < architectureSteps.length - 1 && <FaArrowRight className="architecture-arrow" />}</motion.div>)}</div><div className="engineering-principles"><div><FaShieldAlt /><strong>Security</strong><span>OAuth 2.0 · JWT · role-based access</span></div><div><FaCodeBranch /><strong>Reliability</strong><span>Retries · reconciliation · controlled recovery</span></div><div><FaChartLine /><strong>Observability</strong><span>Logs · metrics · alerts · operational dashboards</span></div><div><FaBrain /><strong>AI where useful</strong><span>Agents for targeted operational workflows</span></div></div></section>

        <section id="work" className="section projects-section"><div className="section-heading"><p>Selected Work</p><h2>Resume-backed engineering case studies</h2></div><div className="projects-grid">{caseStudies.map((project, index) => { const Icon = project.icon; return <motion.article className="project-card" key={project.id} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .6, delay: index * .1 }}><div className="project-card-top"><div className="project-number">{String(index + 1).padStart(2, "0")}</div><Icon /></div><p className="project-eyebrow">{project.eyebrow}</p><h3>{project.title}</h3><p>{project.summary}</p><div className="project-technologies">{project.technologies.map(t => <span key={t}>{t}</span>)}</div><button className="case-study-button" onClick={() => setActiveCase(project)}>Read case study <FaExternalLinkAlt /></button></motion.article>; })}</div></section>

        <section className="ai-section"><div className="ai-inner"><div className="ai-copy"><p className="contact-label">AI Engineering</p><h2>Using AI as an engineering capability — not a buzzword.</h2><p>My resume-backed AI experience focuses on controlled enterprise workflows: analyzing failed records, supporting retries and reprocessing, checking reconciliation results and surfacing exceptions for human follow-up and auditability.</p><div className="ai-tags">{["AI Agents", "LLM APIs", "Spring AI", "LangChain4j", "RAG", "Vector DBs", "MCP", "Prompt Engineering"].map(t => <span key={t}>{t}</span>)}</div></div><div className="ai-visual"><div className="ai-core"><FaBrain /><span>AI Agent</span></div><div className="ai-orbit orbit-a">Analyze</div><div className="ai-orbit orbit-b">Reconcile</div><div className="ai-orbit orbit-c">Reprocess</div><div className="ai-orbit orbit-d">Surface</div></div></div></section>

        <section id="contact" className="contact-section"><motion.div className="contact-card" initial={{ opacity: 0, scale: .97 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true, amount: .3 }} transition={{ duration: .7 }}><p className="contact-label">Let&apos;s Connect</p><h2>Looking for a hands-on senior engineer?</h2><p>Open to Senior Java Full Stack Developer and Senior Software Engineer opportunities focused on secure, scalable, cloud-native applications and enterprise modernization.</p><div className="contact-actions"><a href="mailto:vikas534ai@gmail.com" className="primary-button"><FaEnvelope /> Send Email</a><a href="https://www.linkedin.com/in/tejavikasd534/" target="_blank" rel="noreferrer" className="secondary-button"><FaLinkedin /> View LinkedIn</a><a href="https://github.com/vikas534ai" target="_blank" rel="noreferrer" className="secondary-button"><FaGithub /> View GitHub</a></div></motion.div></section>
      </main>

      <footer className="footer"><div className="footer-container"><a href="#home" className="footer-logo">TV</a><p>© {new Date().getFullYear()} Teja Vikas Donepudi · React + Vite</p><div className="footer-links"><a href="https://github.com/vikas534ai" target="_blank" rel="noreferrer" aria-label="GitHub"><FaGithub /></a><a href="https://www.linkedin.com/in/tejavikasd534/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><FaLinkedin /></a><a href="mailto:vikas534ai@gmail.com" aria-label="Email"><FaEnvelope /></a></div></div></footer>

      {activeCase && <div className="modal-backdrop" onClick={() => setActiveCase(null)}><motion.div className="case-modal" onClick={e => e.stopPropagation()} initial={{ opacity: 0, y: 20, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }}><button className="modal-close" onClick={() => setActiveCase(null)} aria-label="Close">×</button><p className="project-eyebrow">{activeCase.eyebrow}</p><h2>{activeCase.title}</h2><p>{activeCase.summary}</p><ul>{activeCase.details.map(detail => <li key={detail}>{detail}</li>)}</ul><div className="project-technologies">{activeCase.technologies.map(t => <span key={t}>{t}</span>)}</div></motion.div></div>}
    </div>
  );
}

export default App;
